/// 0 to 4
for (i = 0; i < 5; i++) {
    console.log(i)
}

/// 0 to 5
for (i = 0; i <= 5; i++) {
    console.log(i)
}

/// 10 to 1
for (i = 10; i > 0; i--) {
    console.log(i)
}

/// 10 to 0
for (i = 10; i >= 0; i--) {
    console.log(i)
}



