let favouriteMovie = 'Bullet Train';
// Show them in the console how you can change this into another value 
// in the console
// then come back here, switch it to a const.
// Get back to the console and try to change the value of it, 
// an error should appear. Explain that this is the purpose of const
// It's to stop accidental changes of values

let rating = 5;

let favMovieSentence = `My favourite movie is ${favouriteMovie}`

let ratingSentence = `I give it a rating of ${rating} stars!`

let fullSentence = favMovieSentence + ' and ' + ratingSentence;

console.log(fullSentence)
